package com.almurshid.mahalli

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/** زر الاتصال المتحرك: 0 = غير متصل، 1 = جاري الاتصال، 2 = متصل */
class PowerButton(context: Context) : View(context) {

    companion object {
        val COLOR_OFF = Color.parseColor("#6366F1")
        val COLOR_WAIT = Color.parseColor("#F59E0B")
        val COLOR_ON = Color.parseColor("#22C55E")
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var pulse = 0f
    private var spin = 0f
    private var color = COLOR_OFF
    private var colorAnim: ValueAnimator? = null

    private val pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
    }

    private val spinAnim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            spin = it.animatedValue as Float
            invalidate()
        }
    }

    var mode: Int = 0
        set(value) {
            if (field == value) return
            field = value
            val target = when (value) {
                1 -> COLOR_WAIT
                2 -> COLOR_ON
                else -> COLOR_OFF
            }
            colorAnim?.cancel()
            colorAnim = ValueAnimator.ofObject(ArgbEvaluator(), color, target).apply {
                duration = 450
                addUpdateListener {
                    color = it.animatedValue as Int
                    invalidate()
                }
                start()
            }
            if (value == 1) spinAnim.start() else spinAnim.cancel()
            invalidate()
        }

    init {
        isClickable = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        pulseAnim.start()
        if (mode == 1) spinAnim.start()
    }

    override fun onDetachedFromWindow() {
        pulseAnim.cancel()
        spinAnim.cancel()
        colorAnim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun withAlpha(c: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun mix(c1: Int, c2: Int, f: Float): Int =
        ArgbEvaluator().evaluate(f, c1, c2) as Int

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val outer = min(width, height) / 2f
        val base = outer * 0.50f

        // حلقات النبض
        val ringAlpha = if (mode == 2) 0.40f else 0.20f
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = outer * 0.012f + 2f
        for (i in 0..2) {
            val p = (pulse + i / 3f) % 1f
            val rad = base * 1.1f + (outer - base * 1.1f) * p
            paint.color = withAlpha(color, ((1f - p) * ringAlpha * 255).toInt())
            canvas.drawCircle(cx, cy, rad, paint)
        }

        // التوهج
        paint.style = Paint.Style.FILL
        paint.color = withAlpha(color, 45)
        canvas.drawCircle(cx, cy, base * 1.18f, paint)

        // جسم الزر
        paint.shader = RadialGradient(
            cx, cy - base * 0.35f, base * 1.3f,
            mix(color, Color.WHITE, 0.30f), mix(color, Color.BLACK, 0.28f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, base, paint)
        paint.shader = null

        // حلقة الانتظار الدوّارة
        if (mode == 1) {
            val rr = base * 1.08f
            oval.set(cx - rr, cy - rr, cx + rr, cy + rr)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = base * 0.07f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = withAlpha(Color.WHITE, 230)
            canvas.drawArc(oval, spin, 100f, false, paint)
        }

        // أيقونة التشغيل
        val ic = base * 0.36f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = base * 0.09f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.WHITE
        oval.set(cx - ic, cy - ic, cx + ic, cy + ic)
        canvas.drawArc(oval, -55f, 290f, false, paint)
        canvas.drawLine(cx, cy - ic * 1.2f, cx, cy - ic * 0.15f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN ->
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        return super.onTouchEvent(event)
    }
}
