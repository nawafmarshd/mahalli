package com.almurshid.mahalli

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val REQ_VPN = 1
        const val REQ_PICK = 2
        const val TUNNEL = "mahalli"
        val BG = Color.parseColor("#0B1220")
        val CARD = Color.parseColor("#151E31")
        val SUB = Color.parseColor("#8A97B0")
        val GREEN = Color.parseColor("#22C55E")
        val RED = Color.parseColor("#F87171")
        val AMBER = Color.parseColor("#F59E0B")
        val INDIGO = Color.parseColor("#6366F1")
        val SELECTED = Color.parseColor("#262F4D")
        const val FILTER_DNS = "DNS = 1.1.1.3, 1.0.0.3"
    }

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var backend: GoBackend
    private lateinit var prefs: SharedPreferences
    private lateinit var power: PowerButton
    private lateinit var statusText: TextView
    private lateinit var subText: TextView
    private lateinit var timeText: TextView
    private lateinit var dataText: TextView
    private lateinit var serverText: TextView
    private lateinit var configInfo: TextView
    private lateinit var homePage: LinearLayout
    private lateinit var settingsPage: LinearLayout
    private lateinit var tabHome: TextView
    private lateinit var tabSettings: TextView

    private var state = 0
    private var connectedAt = 0L
    @Volatile private var busy = false
    private val handler = Handler(Looper.getMainLooper())

    private val tunnel = object : Tunnel {
        override fun getName() = TUNNEL
        override fun onStateChange(newState: Tunnel.State) {}
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1000)
        }
    }

    // ---------------------------------------------------------------- دورة الحياة

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        backend = GoBackend(applicationContext)
        window.statusBarColor = BG
        window.navigationBarColor = CARD
        buildUi()
        refreshConfigInfo()
        val running = try {
            backend.runningTunnelNames.contains(TUNNEL)
        } catch (e: Exception) {
            false
        }
        setState(if (running) 2 else 0)
    }

    override fun onResume() {
        super.onResume()
        if (state == 2) {
            handler.removeCallbacks(ticker)
            handler.post(ticker)
        }
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_VPN -> connect()
            REQ_PICK -> data?.data?.let { importConfig(it) }
        }
    }

    // ---------------------------------------------------------------- أدوات الواجهة

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun lp(w: Int, h: Int, top: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = top }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 18)
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    private fun column(value: TextView, caption: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(value)
            addView(label(caption, 12f, SUB).apply { gravity = Gravity.CENTER })
        }

    private fun button(text: String, subtle: Boolean = false, onClick: () -> Unit): TextView =
        label(text, 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(if (subtle) SELECTED else INDIGO, 14)
            setOnClickListener { onClick() }
        }

    private fun tab(text: String, onClick: () -> Unit): TextView =
        label(text, 14f, SUB, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { onClick() }
        }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun buildUi() {
        // ---------- الصفحة الرئيسية
        statusText = label("", 26f, RED, true).apply { gravity = Gravity.CENTER }
        subText = label("", 14f, SUB).apply { gravity = Gravity.CENTER }
        power = PowerButton(this).apply { setOnClickListener { onPowerClick() } }
        timeText = label("00:00:00", 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        dataText = label("0 KB", 16f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        serverText = label("", 16f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }

        val infoCard = card().apply {
            orientation = LinearLayout.HORIZONTAL
            addView(column(timeText, "المدة"), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(column(dataText, "البيانات"), LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(column(serverText, "الخادم"), LinearLayout.LayoutParams(0, WRAP, 1f))
        }

        homePage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(32), dp(20), dp(12))
            addView(label("اتصالات المرشد", 24f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, lp(MATCH, WRAP))
            addView(label("اتصال آمن ومجاني", 13f, SUB).apply { gravity = Gravity.CENTER }, lp(MATCH, WRAP, dp(4)))
            addView(statusText, lp(MATCH, WRAP, dp(32)))
            addView(subText, lp(MATCH, WRAP, dp(4)))
            addView(
                power,
                LinearLayout.LayoutParams(dp(300), dp(300)).apply {
                    topMargin = dp(12)
                    gravity = Gravity.CENTER_HORIZONTAL
                }
            )
            addView(infoCard, lp(MATCH, WRAP, dp(8)))
        }

        // ---------- صفحة الإعدادات
        configInfo = label("", 13f, SUB)

        val filterSwitch = Switch(this).apply {
            isChecked = prefs.getBoolean("filter", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("filter", checked).apply()
                toast(if (state == 0) "تم الحفظ" else "سيُطبَّق عند الاتصال القادم")
            }
        }

        val filterCard = card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val texts = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(label("حجب المحتوى الإباحي", 16f, Color.WHITE, true))
                addView(label("يحجب المواقع الإباحية والخبيثة قدر الإمكان", 12f, SUB), lp(MATCH, WRAP, dp(4)))
            }
            addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(filterSwitch)
        }

        val configCard = card().apply {
            addView(label("ملف الإعداد (WireGuard)", 16f, Color.WHITE, true))
            addView(configInfo, lp(MATCH, WRAP, dp(4)))
            addView(button("استيراد ملف .conf") { pickFile() }, lp(MATCH, dp(48), dp(14)))
            addView(button("استخدام الخادم الافتراضي", subtle = true) { clearImported() }, lp(MATCH, dp(48), dp(8)))
        }

        settingsPage = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(12))
            addView(label("الإعدادات", 24f, Color.WHITE, true))
            addView(filterCard, lp(MATCH, WRAP, dp(20)))
            addView(configCard, lp(MATCH, WRAP, dp(12)))
            addView(
                label("الإصدار 2.0  •  اتصالات المرشد", 12f, SUB).apply { gravity = Gravity.CENTER },
                lp(MATCH, WRAP, dp(24))
            )
            visibility = View.GONE
        }

        // ---------- شريط التبويبات
        tabHome = tab("الرئيسية") { showTab(0) }
        tabSettings = tab("الإعدادات") { showTab(1) }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(CARD)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(tabHome, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
            addView(tabSettings, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        }

        val pages = FrameLayout(this).apply {
            addView(homePage, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(settingsPage, FrameLayout.LayoutParams(MATCH, MATCH))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(pages, LinearLayout.LayoutParams(MATCH, 0, 1f))
            addView(bar, lp(MATCH, WRAP))
        }
        setContentView(root)
        showTab(0, false)
    }

    private fun showTab(index: Int, animate: Boolean = true) {
        val show: View = if (index == 0) homePage else settingsPage
        val hide: View = if (index == 0) settingsPage else homePage

        tabHome.background = if (index == 0) rounded(SELECTED, 20) else null
        tabHome.setTextColor(if (index == 0) Color.WHITE else SUB)
        tabSettings.background = if (index == 1) rounded(SELECTED, 20) else null
        tabSettings.setTextColor(if (index == 1) Color.WHITE else SUB)

        if (!animate) {
            hide.visibility = View.GONE
            show.visibility = View.VISIBLE
            show.alpha = 1f
            return
        }
        if (show.visibility == View.VISIBLE) return
        hide.animate().alpha(0f).setDuration(140).withEndAction {
            hide.visibility = View.GONE
            show.alpha = 0f
            show.visibility = View.VISIBLE
            show.animate().alpha(1f).setDuration(220).start()
        }.start()
    }

    // ---------------------------------------------------------------- الحالة والاتصال

    private fun setState(s: Int, message: String? = null) {
        state = s
        power.mode = s
        val (title, color, sub) = when (s) {
            1 -> Triple("جاري الاتصال...", AMBER, "لحظات من فضلك")
            2 -> Triple("اتصالك آمن", GREEN, "أنت متصل بأمان")
            else -> Triple("غير متصل", RED, "اضغط الزر للاتصال")
        }
        statusText.text = title
        statusText.setTextColor(color)
        subText.text = message ?: sub
        statusText.alpha = 0f
        statusText.animate().alpha(1f).setDuration(300).start()

        handler.removeCallbacks(ticker)
        if (s == 2) {
            connectedAt = prefs.getLong("since", 0L)
            if (connectedAt == 0L) {
                connectedAt = System.currentTimeMillis()
                prefs.edit().putLong("since", connectedAt).apply()
            }
            handler.post(ticker)
        } else if (s == 0) {
            prefs.edit().putLong("since", 0L).apply()
            timeText.text = "00:00:00"
            dataText.text = "0 KB"
        }
    }

    private fun updateStats() {
        val secs = ((System.currentTimeMillis() - connectedAt) / 1000).coerceAtLeast(0)
        timeText.text = String.format(Locale.US, "%02d:%02d:%02d", secs / 3600, (secs % 3600) / 60, secs % 60)
        try {
            val st = backend.getStatistics(tunnel)
            dataText.text = fmtBytes(st.totalRx() + st.totalTx())
        } catch (e: Exception) {
            // لا شيء
        }
    }

    private fun fmtBytes(b: Long): String = when {
        b >= 1_073_741_824L -> String.format(Locale.US, "%.2f GB", b / 1_073_741_824.0)
        b >= 1_048_576L -> String.format(Locale.US, "%.1f MB", b / 1_048_576.0)
        else -> "${b / 1024} KB"
    }

    private fun onPowerClick() {
        if (busy) return
        if (state == 2) {
            disconnect()
        } else {
            val intent = VpnService.prepare(this)
            if (intent != null) startActivityForResult(intent, REQ_VPN) else connect()
        }
    }

    private fun connect() {
        if (busy) return
        busy = true
        setState(1)
        thread {
            try {
                val config = buildConfig()
                backend.setState(tunnel, Tunnel.State.UP, config)
                runOnUiThread { setState(2) }
            } catch (e: Exception) {
                val msg = "فشل الاتصال: ${e.message ?: e.javaClass.simpleName}"
                runOnUiThread { setState(0, msg) }
            } finally {
                busy = false
            }
        }
    }

    private fun disconnect() {
        if (busy) return
        busy = true
        thread {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
                runOnUiThread { setState(0) }
            } catch (e: Exception) {
                val msg = "خطأ: ${e.message ?: e.javaClass.simpleName}"
                runOnUiThread { setState(2, msg) }
            } finally {
                busy = false
            }
        }
    }

    // ---------------------------------------------------------------- الإعداد

    private fun buildConfig(): Config {
        var text = prefs.getString("conf", null) ?: warpConfigText()
        if (prefs.getBoolean("filter", true)) text = applyFilterDns(text)
        return Config.parse(ByteArrayInputStream(text.toByteArray()))
    }

    private fun applyFilterDns(text: String): String {
        val lines = text.lines().filterNot { it.trim().startsWith("DNS", ignoreCase = true) }.toMutableList()
        val idx = lines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
        if (idx >= 0) lines.add(idx + 1, FILTER_DNS)
        return lines.joinToString("\n")
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, REQ_PICK)
    }

    private fun importConfig(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("تعذّرت قراءة الملف")
            Config.parse(ByteArrayInputStream(text.toByteArray())) // للتحقق من صحة الملف
            var name = "ملف مستورد"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
            }
            prefs.edit()
                .putString("conf", text)
                .putString("conf_name", name.removeSuffix(".conf"))
                .apply()
            refreshConfigInfo()
            toast(if (state == 0) "تم استيراد الملف" else "تم الاستيراد، أعد الاتصال لتطبيقه")
        } catch (e: Exception) {
            toast("الملف غير صالح")
        }
    }

    private fun clearImported() {
        prefs.edit().remove("conf").remove("conf_name").apply()
        refreshConfigInfo()
        toast(if (state == 0) "تم" else "أعد الاتصال لتطبيق التغيير")
    }

    private fun refreshConfigInfo() {
        val name = prefs.getString("conf_name", null)
        configInfo.text = if (name != null) {
            "الملف الحالي: $name"
        } else {
            "لا يوجد ملف مستورد، يُستخدم الخادم الافتراضي (Cloudflare WARP)."
        }
        serverText.text = name ?: "Cloudflare"
    }

    // ---------------------------------------------------------------- الخادم الافتراضي (Cloudflare WARP)

    private fun warpConfigText(): String {
        if (!prefs.contains("w_priv")) registerWarp()
        return """
            [Interface]
            PrivateKey = ${prefs.getString("w_priv", "")}
            Address = ${prefs.getString("w_v4", "")}/32, ${prefs.getString("w_v6", "")}/128
            DNS = 1.1.1.1, 1.0.0.1
            MTU = 1280

            [Peer]
            PublicKey = ${prefs.getString("w_peer", "")}
            AllowedIPs = 0.0.0.0/0, ::/0
            Endpoint = 162.159.192.1:2408
        """.trimIndent()
    }

    private fun registerWarp() {
        val keys = KeyPair()
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.000'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val body = JSONObject()
            .put("key", keys.publicKey.toBase64())
            .put("install_id", "")
            .put("fcm_token", "")
            .put("tos", fmt.format(Date()))
            .put("type", "Android")
            .put("model", "PC")
            .put("locale", "en_US")

        val conn = URL("https://api.cloudflareclient.com/v0a2158/reg").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("CF-Client-Version", "a-6.3-2158")
        conn.setRequestProperty("User-Agent", "okhttp/3.12.1")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        if (code !in 200..299) throw RuntimeException("تسجيل الخدمة فشل ($code)")
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val cfg = json.getJSONObject("config")
        val peer = cfg.getJSONArray("peers").getJSONObject(0)
        val addrs = cfg.getJSONObject("interface").getJSONObject("addresses")

        prefs.edit()
            .putString("w_priv", keys.privateKey.toBase64())
            .putString("w_peer", peer.getString("public_key"))
            .putString("w_v4", addrs.getString("v4"))
            .putString("w_v6", addrs.getString("v6"))
            .apply()
    }
}
